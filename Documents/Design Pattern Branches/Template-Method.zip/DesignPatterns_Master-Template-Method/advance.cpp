/***********************************************************************
 * Source File:
 *    Advance : The bird movement algorithm
 * Summary:
 *    Template method and step implementations for bird movement
 ************************************************************************/

#include "advance.h"
#include "bird.h"

int    randomInt  (int    min, int    max);
double randomFloat(double min, double max);

/**********************
 * ADVANCE :: ADVANCE
 * Template method - executes all four steps in a fixed order
 **********************/
void Advance::advance(Bird* bird)
{
   inertia(bird);
   drag(bird);
   buoyancy(bird);
   turn(bird);
   if (bird->isOutOfBounds())
   {
      bird->kill();
      bird->setPoints(bird->getPoints() * -1);
   }
}

/**********************
 * ADVANCE :: INERTIA
 * Move the bird forward based on its current velocity
 **********************/
void Advance::inertia(Bird* bird)
{
   Position pos = bird->getPosition();
   pos.add(bird->getVelocity());
   *bird = pos;
}

/**********************
 * STANDARD ADVANCE :: DRAG
 * Small drag slows the bird slightly each frame
 **********************/
void StandardAdvance::drag(Bird* bird)
{
   Velocity vel = bird->getVelocity();
   vel *= 0.995;
   *bird = vel;
}

/**********************
 * FLOATER ADVANCE :: DRAG
 * Heavy drag slows the floater more aggressively
 **********************/
void FloaterAdvance::drag(Bird* bird)
{
   Velocity vel = bird->getVelocity();
   vel *= 0.990;
   *bird = vel;
}

/**********************
 * FLOATER ADVANCE :: BUOYANCY
 * Anti-gravity pushes the floater upward each frame
 **********************/
void FloaterAdvance::buoyancy(Bird* bird)
{
   Velocity vel = bird->getVelocity();
   vel.addDy(0.05);
   *bird = vel;
}

/**********************
 * SINKER ADVANCE :: BUOYANCY
 * Gravity pulls the sinker downward each frame
 **********************/
void SinkerAdvance::buoyancy(Bird* bird)
{
   Velocity vel = bird->getVelocity();
   vel.addDy(-0.07);
   *bird = vel;
}

/**********************
 * CRAZY ADVANCE :: TURN
 * Random velocity change roughly every half second
 **********************/
void CrazyAdvance::turn(Bird* bird)
{
   if (randomInt(0, 15) == 0)
   {
      Velocity vel = bird->getVelocity();
      vel.addDy(randomFloat(-1.5, 1.5));
      vel.addDx(randomFloat(-1.5, 1.5));
      *bird = vel;
   }
}
