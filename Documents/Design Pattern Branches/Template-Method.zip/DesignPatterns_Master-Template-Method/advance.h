/***********************************************************************
 * Header File:
 *    Advance : The bird movement algorithm
 * Summary:
 *    Abstract template class and concrete subclasses for bird movement
 ************************************************************************/

#pragma once

class Bird;

/**********************
 * ADVANCE
 * Abstract template class for bird movement.
 * advance() is the template method; the four steps are private virtual.
 **********************/
class Advance
{
public:
   virtual ~Advance() { }
   void advance(Bird* bird);
private:
   virtual void inertia(Bird* bird);
   virtual void drag(Bird* bird)     { }
   virtual void buoyancy(Bird* bird) { }
   virtual void turn(Bird* bird)     { }
};

/**********************
 * STANDARD ADVANCE
 * Slight drag, straight flight
 **********************/
class StandardAdvance : public Advance
{
private:
   void drag(Bird* bird) override;
};

/**********************
 * FLOATER ADVANCE
 * Heavy drag and anti-gravity buoyancy
 **********************/
class FloaterAdvance : public Advance
{
private:
   void drag(Bird* bird)     override;
   void buoyancy(Bird* bird) override;
};

/**********************
 * SINKER ADVANCE
 * Gravity pulls the bird downward
 **********************/
class SinkerAdvance : public Advance
{
private:
   void buoyancy(Bird* bird) override;
};

/**********************
 * CRAZY ADVANCE
 * Random direction changes every half second
 **********************/
class CrazyAdvance : public Advance
{
private:
   void turn(Bird* bird) override;
};
