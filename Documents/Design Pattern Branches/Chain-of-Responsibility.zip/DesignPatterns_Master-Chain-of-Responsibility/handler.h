/***********************************************************************
 * Header File:
 *    HANDLER
 * Author:
 *    David Schaad
 * Summary:
 *    Handlers for Chain of Responsibility design pattern
 ************************************************************************/

#pragma once

#include "uiInteract.h"


class Skeet;
/*********************************************
 * HANDLER
 * Abstract handler for all derived handlers
 *********************************************/
class Handler
{
public:
   virtual bool handleRequest(const UserInput & ui, Skeet * skeet) = 0;
};

/*********************************************
 * HANDLER GAME OVER
 *********************************************/
class HandlerGameOver : public Handler
{
   bool handleRequest(const UserInput& ui, Skeet* skeet);
};

/*********************************************
 * HANDLER PELLET
 *********************************************/
class HandlerPellet : public Handler
{
   bool handleRequest(const UserInput& ui, Skeet* skeet);
};

/*********************************************
 * HANDLER MISSILE
 *********************************************/
class HandlerMissile : public Handler
{
   bool handleRequest(const UserInput& ui, Skeet* skeet);
};

/*********************************************
 * HANDLER BOMB
 *********************************************/
class HandlerBomb : public Handler
{
   bool handleRequest(const UserInput& ui, Skeet* skeet);
};

/*********************************************
 * HANDLER MOVE GUN
 *********************************************/
class HandlerMoveGun : public Handler
{
   bool handleRequest(const UserInput& ui, Skeet* skeet);
};

/*********************************************
 * HANDLER GUIDE MISSILE
 *********************************************/
class HandlerGuideMissile : public Handler
{
   bool handleRequest(const UserInput& ui, Skeet* skeet);
};