/*********************************************
 * HANDLER
 *********************************************/
#include "handler.h"
#include "bullet.h"
#include "skeet.h"

/*********************************************
 * HANDLER GAME OVER HANDLE REQUEST
 *********************************************/
bool HandlerGameOver::handleRequest(const UserInput& ui, Skeet* skeet)
{
   if (ui.isSpace())
   {
      skeet->reset();
      return true;
   }
   return false;
}

/*********************************************
 * HANDLER PELLET HANDLE REQUEST
 *********************************************/
bool HandlerPellet::handleRequest(const UserInput& ui, Skeet* skeet)
{
   if (ui.isSpace())
   {
      Pellet* p = new Pellet(skeet->getGunAngle());
      skeet->addBullet(p);
      skeet->adjustScore(0 - p->getValue());
      return true;
   }
   return false;
}

/*********************************************
 * HANDLER MISSILE HANDLE REQUEST
 *********************************************/
bool HandlerMissile::handleRequest(const UserInput& ui, Skeet* skeet)
{
   if (ui.isM())
   {
      Missile* p = new Missile(skeet->getGunAngle());
      skeet->addBullet(p);
      skeet->adjustScore(0 - p->getValue());
      return true;
   }
   return false;
}

/*********************************************
 * HANDLER BOMB HANDLE REQUEST
 *********************************************/
bool HandlerBomb::handleRequest(const UserInput& ui, Skeet* skeet)
{
   if (ui.isB())
   {
      Bomb* p = new Bomb(skeet->getGunAngle());
      skeet->addBullet(p);
      skeet->adjustScore(0 - p->getValue());
      return true;
   }
   return false;
}

/*********************************************
 * HANDLER MOVE GUN HANDLE REQUEST
 *********************************************/
bool HandlerMoveGun::handleRequest(const UserInput& ui, Skeet* skeet)
{
   skeet->moveGun(ui.isUp() + ui.isRight(), ui.isDown() + ui.isLeft());
   return false;
}

/*********************************************
 * HANDLER GUIDE MISSILE HANDLE REQUEST
 *********************************************/
bool HandlerGuideMissile::handleRequest(const UserInput& ui, Skeet* skeet)
{
   skeet->moveMissile(ui.isUp() + ui.isRight(), ui.isDown() + ui.isLeft());
   return false;
}